
#include "CONSTANTDECLARATIONS.h"
#include "Graphics.h"
void Setup()
{
	//FULLRESOLUTION  // ū ȭ�� 
	SETRESOLUTION // ���� ȭ�� 
	Board_FastTrack3();
	Board_RatRace();
	Content_Board();
	RatRace_Board_elements();
	FastTrack_Board_elements();

}